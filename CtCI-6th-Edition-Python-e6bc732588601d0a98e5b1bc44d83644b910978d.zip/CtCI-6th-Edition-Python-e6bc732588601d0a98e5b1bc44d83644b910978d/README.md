# Python Solutions to *Cracking the Coding Interview, 6th Edition*

This is a **Python** solutions for the book [Cracking the Coding Interview, 6th Edition](https://www.careercup.com/book) by *Gayle Laakmann McDowell*.

## How to use?

To run the programs, just use the `python ChapterX/filename.py` command.

The test cases are included in the solution files.
